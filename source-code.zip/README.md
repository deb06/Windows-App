#Windows Program Manager App

I followed this video, but did make some slight changes:

https://www.youtube.com/watch?v=jE-SpRI3K5g